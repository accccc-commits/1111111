from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File, Form
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import IntranetAsset, VulnHistory, PortHistory, CSegmentRegion
from ..schemas import (
    AssetCreate,
    AssetUpdate,
    AssetResponse,
    AssetDetailResponse,
    PaginatedAssets,
    VulnHistoryCreate,
    VulnHistoryResponse,
    PortHistoryCreate,
    PortHistoryResponse,
    ProbeRequest,
    ProbeResult,
    BatchProbeRequest,
    AssetImportResult,
    CSegmentRegionItem,
    RegionImportResult,
    OverviewStats,
    CSegmentStatItem,
    BatchDeleteRequest,
    BatchUpdateRequest,
    BatchOperationResult,
    BatchDeletePortsRequest,
    BatchDeleteVulnsRequest,
    BatchDeleteRegionMappingsRequest,
    ProbeFilterRequest,
)
from ..services.probe import ping_ip, is_valid_ip
from ..services.import_service import load_preview_from_file, apply_import
from ..services.asset_query import build_asset_query, assets_to_response_list, get_counts_for_assets
from ..services.export_service import assets_to_csv, c_segment_stats_to_csv, asset_ports_to_csv
from ..services.region_service import (
    parse_region_csv,
    import_region_mappings,
    sync_all_asset_regions,
    apply_c_segment_to_asset,
)
from ..services.stats_service import get_overview_stats, get_c_segment_stats

router = APIRouter()


def _get_asset_or_404(asset_id: int, db: Session) -> IntranetAsset:
    asset = db.query(IntranetAsset).filter(IntranetAsset.id == asset_id).first()
    if not asset:
        raise HTTPException(status_code=404, detail="资产不存在")
    return asset


@router.get("/assets", response_model=PaginatedAssets)
def list_assets(
    skip: int = 0,
    limit: int = 50,
    q: Optional[str] = Query(None, description="IP/主机名/用途/部门/属性 模糊搜索"),
    department: Optional[str] = None,
    c_segment: Optional[str] = None,
    region: Optional[str] = None,
    is_alive: Optional[bool] = None,
    db: Session = Depends(get_db),
):
    query = build_asset_query(db, q, department, c_segment, region, is_alive)
    total = query.count()
    items = (
        query.order_by(IntranetAsset.updated_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
    return PaginatedAssets(
        total=total, items=assets_to_response_list(db, items)
    )


@router.get("/assets/export")
def export_assets(
    q: Optional[str] = None,
    department: Optional[str] = None,
    c_segment: Optional[str] = None,
    region: Optional[str] = None,
    is_alive: Optional[bool] = None,
    db: Session = Depends(get_db),
):
    """导出当前筛选条件下的全部资产为 CSV"""
    query = build_asset_query(db, q, department, c_segment, region, is_alive)
    assets = query.order_by(IntranetAsset.ip.asc()).all()
    ids = [a.id for a in assets]
    port_counts, vuln_counts = get_counts_for_assets(db, ids)
    content = assets_to_csv(assets, port_counts, vuln_counts)
    return PlainTextResponse(
        content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=assets_export.csv"},
    )


@router.post("/assets/batch-delete", response_model=BatchOperationResult)
def batch_delete_assets(body: BatchDeleteRequest, db: Session = Depends(get_db)):
    if not body.asset_ids:
        raise HTTPException(status_code=400, detail="请选择要删除的资产")
    rows = (
        db.query(IntranetAsset)
        .filter(IntranetAsset.id.in_(body.asset_ids))
        .all()
    )
    for row in rows:
        db.delete(row)
    db.commit()
    return BatchOperationResult(
        affected=len(rows),
        message=f"已删除 {len(rows)} 条资产（含关联端口/漏洞记录）",
    )


@router.post("/assets/batch-update", response_model=BatchOperationResult)
def batch_update_assets(body: BatchUpdateRequest, db: Session = Depends(get_db)):
    if not body.asset_ids:
        raise HTTPException(status_code=400, detail="请选择要更新的资产")
    updates = body.model_dump(exclude_unset=True, exclude={"asset_ids"})
    if not updates:
        raise HTTPException(status_code=400, detail="请至少填写一项要更新的字段")
    rows = (
        db.query(IntranetAsset)
        .filter(IntranetAsset.id.in_(body.asset_ids))
        .all()
    )
    for row in rows:
        for key, value in updates.items():
            if value is not None and value != "":
                setattr(row, key, value)
        row.updated_at = datetime.utcnow()
    db.commit()
    return BatchOperationResult(
        affected=len(rows),
        message=f"已更新 {len(rows)} 条资产",
    )


@router.get("/regions", response_model=List[str])
def list_regions(db: Session = Depends(get_db)):
    rows = (
        db.query(IntranetAsset.region)
        .filter(IntranetAsset.region.isnot(None))
        .distinct()
        .all()
    )
    return sorted({r[0] for r in rows if r[0]})


@router.get("/c-segments", response_model=List[str])
def list_c_segments(db: Session = Depends(get_db)):
    rows = (
        db.query(IntranetAsset.c_segment)
        .filter(IntranetAsset.c_segment.isnot(None))
        .distinct()
        .all()
    )
    return sorted({r[0] for r in rows if r[0]})


@router.get("/stats/overview", response_model=OverviewStats)
def stats_overview(db: Session = Depends(get_db)):
    return OverviewStats(**get_overview_stats(db))


@router.get("/stats/c-segments", response_model=List[CSegmentStatItem])
def stats_by_c_segment(db: Session = Depends(get_db)):
    return get_c_segment_stats(db)


@router.get("/stats/c-segments/export")
def export_c_segment_stats(db: Session = Depends(get_db)):
    stats = get_c_segment_stats(db)
    content = c_segment_stats_to_csv(stats)
    return PlainTextResponse(
        content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=c_segment_stats.csv"},
    )


@router.get("/c-segment-regions", response_model=List[CSegmentRegionItem])
def list_c_segment_regions(db: Session = Depends(get_db)):
    return (
        db.query(CSegmentRegion)
        .order_by(CSegmentRegion.c_segment.asc())
        .all()
    )


@router.post("/c-segment-regions/import", response_model=RegionImportResult)
async def import_c_segment_regions(
    file: UploadFile = File(...),
    sync_assets: bool = Form(True),
    db: Session = Depends(get_db),
):
    """导入 C 段 -> 区域/归属 CSV，并可同步到全部资产"""
    if not file.filename:
        raise HTTPException(status_code=400, detail="请选择文件")
    content = (await file.read()).decode("utf-8-sig", errors="replace")
    mappings, errors = parse_region_csv(content)
    if not mappings:
        raise HTTPException(
            status_code=400,
            detail=errors[0] if errors else "未解析到有效数据",
        )
    result = import_region_mappings(db, mappings)
    synced = None
    if sync_assets:
        sync = sync_all_asset_regions(db)
        synced = sync["assets_updated"]
    return RegionImportResult(
        created=result["created"],
        updated=result["updated"],
        total=result["total"],
        errors=errors[:20],
        assets_synced=synced,
    )


@router.post("/c-segment-regions/sync")
def sync_regions_to_assets(db: Session = Depends(get_db)):
    """按映射表为全部资产回填 C 段与归属"""
    return sync_all_asset_regions(db)


@router.delete("/c-segment-regions/{mapping_id}")
def delete_c_segment_region(mapping_id: int, db: Session = Depends(get_db)):
    row = db.query(CSegmentRegion).filter(CSegmentRegion.id == mapping_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="映射不存在")
    db.delete(row)
    db.commit()
    return {"ok": True}


@router.post("/c-segment-regions/batch-delete", response_model=BatchOperationResult)
def batch_delete_region_mappings(
    body: BatchDeleteRegionMappingsRequest, db: Session = Depends(get_db)
):
    if not body.mapping_ids:
        raise HTTPException(status_code=400, detail="请选择映射记录")
    rows = (
        db.query(CSegmentRegion)
        .filter(CSegmentRegion.id.in_(body.mapping_ids))
        .all()
    )
    for row in rows:
        db.delete(row)
    db.commit()
    return BatchOperationResult(
        affected=len(rows), message=f"已删除 {len(rows)} 条 C 段映射"
    )


@router.get("/departments", response_model=List[str])
def list_departments(db: Session = Depends(get_db)):
    rows = (
        db.query(IntranetAsset.department)
        .filter(IntranetAsset.department.isnot(None))
        .distinct()
        .all()
    )
    return sorted({r[0] for r in rows if r[0]})


@router.get("/assets/{asset_id}", response_model=AssetDetailResponse)
def get_asset(asset_id: int, db: Session = Depends(get_db)):
    asset = _get_asset_or_404(asset_id, db)
    vulns = (
        db.query(VulnHistory)
        .filter(VulnHistory.asset_id == asset_id)
        .order_by(VulnHistory.found_at.desc())
        .all()
    )
    ports = (
        db.query(PortHistory)
        .filter(PortHistory.asset_id == asset_id)
        .order_by(PortHistory.observed_at.desc(), PortHistory.port.asc())
        .all()
    )
    data = AssetDetailResponse.model_validate(asset)
    data.vuln_history = vulns
    data.port_history = ports
    return data


@router.get("/assets/{asset_id}/ports/export")
def export_asset_ports(asset_id: int, db: Session = Depends(get_db)):
    asset = _get_asset_or_404(asset_id, db)
    ports = (
        db.query(PortHistory)
        .filter(PortHistory.asset_id == asset_id)
        .order_by(PortHistory.port.asc())
        .all()
    )
    content = asset_ports_to_csv(ports, asset.ip)
    return PlainTextResponse(
        content,
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f"attachment; filename=ports_{asset.ip}.csv"
        },
    )


@router.post("/assets/import", response_model=AssetImportResult)
async def import_assets(
    file: UploadFile = File(...),
    import_type: str = Form(..., description="ez-url 或 ip-port"),
    department: Optional[str] = Form(None),
    owner: Optional[str] = Form(None),
    text_mode: bool = Form(False),
    resolve_dns: bool = Form(True),
    db: Session = Depends(get_db),
):
    """
    批量导入资产。
    - ez-url: EZ 导出的 CSV（URL/Title/指纹/评分/返回码 等），从 URL 解析 IP 与端口并写入历史端口
    - ip-port: IP+端口 CSV/文本（IP,端口,协议,服务 等）
    """
    if import_type not in ("ez-url", "ip-port"):
        raise HTTPException(status_code=400, detail="import_type 须为 ez-url 或 ip-port")

    if not file.filename:
        raise HTTPException(status_code=400, detail="请选择文件")

    ext = file.filename.lower().rsplit(".", 1)[-1]
    if ext not in ("csv", "txt", "text") and not text_mode:
        raise HTTPException(status_code=400, detail="支持 .csv 或 .txt 文件")

    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="文件为空")

    preview = load_preview_from_file(
        content,
        file.filename,
        import_type,
        text_mode=text_mode or ext == "txt",
        resolve_dns=resolve_dns and import_type == "ez-url",
    )
    if not preview.rows and preview.errors:
        raise HTTPException(status_code=400, detail="; ".join(preview.errors[:5]))

    result = apply_import(
        db,
        preview,
        default_department=department,
        default_owner=owner,
        skip_domain_only=True,
    )
    return AssetImportResult(**result)


@router.post("/assets/import/text", response_model=AssetImportResult)
def import_assets_text(
    text: str = Form(...),
    import_type: str = Form(...),
    department: Optional[str] = Form(None),
    owner: Optional[str] = Form(None),
    resolve_dns: bool = Form(True),
    db: Session = Depends(get_db),
):
    """粘贴文本导入：每行一条 URL 或 IP:端口 / IP,端口,协议,服务"""
    from ..services.import_parser import parse_text_content

    if import_type not in ("ez-url", "ip-port"):
        raise HTTPException(status_code=400, detail="import_type 须为 ez-url 或 ip-port")

    preview = parse_text_content(
        text, import_type, resolve_dns=resolve_dns and import_type == "ez-url"
    )
    result = apply_import(
        db,
        preview,
        default_department=department,
        default_owner=owner,
        skip_domain_only=True,
    )
    return AssetImportResult(**result)


@router.post("/assets", response_model=AssetResponse)
def create_asset(payload: AssetCreate, db: Session = Depends(get_db)):
    ip = payload.ip.strip()
    if not is_valid_ip(ip):
        raise HTTPException(status_code=400, detail="IP 格式不正确")
    if db.query(IntranetAsset).filter(IntranetAsset.ip == ip).first():
        raise HTTPException(status_code=400, detail="该 IP 已存在")

    data = payload.model_dump()
    data["ip"] = ip
    asset = IntranetAsset(**data)
    db.add(asset)
    db.flush()
    apply_c_segment_to_asset(asset, db)
    db.commit()
    db.refresh(asset)
    return asset


@router.put("/assets/{asset_id}", response_model=AssetResponse)
def update_asset(
    asset_id: int, payload: AssetUpdate, db: Session = Depends(get_db)
):
    asset = _get_asset_or_404(asset_id, db)
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(asset, key, value)
    asset.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(asset)
    return asset


@router.delete("/assets/{asset_id}")
def delete_asset(asset_id: int, db: Session = Depends(get_db)):
    asset = _get_asset_or_404(asset_id, db)
    db.delete(asset)
    db.commit()
    return {"ok": True}


# --- 历史漏洞 ---
@router.post(
    "/assets/{asset_id}/vulns", response_model=VulnHistoryResponse
)
def add_vuln(
    asset_id: int, payload: VulnHistoryCreate, db: Session = Depends(get_db)
):
    _get_asset_or_404(asset_id, db)
    row = VulnHistory(asset_id=asset_id, **payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/vulns/{vuln_id}")
def delete_vuln(vuln_id: int, db: Session = Depends(get_db)):
    row = db.query(VulnHistory).filter(VulnHistory.id == vuln_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="记录不存在")
    db.delete(row)
    db.commit()
    return {"ok": True}


# --- 历史端口 ---
@router.post(
    "/assets/{asset_id}/ports", response_model=PortHistoryResponse
)
def add_port(
    asset_id: int, payload: PortHistoryCreate, db: Session = Depends(get_db)
):
    _get_asset_or_404(asset_id, db)
    row = PortHistory(asset_id=asset_id, **payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/assets/{asset_id}/ports")
def clear_asset_ports(asset_id: int, db: Session = Depends(get_db)):
    _get_asset_or_404(asset_id, db)
    n = (
        db.query(PortHistory)
        .filter(PortHistory.asset_id == asset_id)
        .delete(synchronize_session=False)
    )
    db.commit()
    return BatchOperationResult(affected=n, message=f"已清空 {n} 条端口记录")


@router.delete("/assets/{asset_id}/vulns")
def clear_asset_vulns(asset_id: int, db: Session = Depends(get_db)):
    _get_asset_or_404(asset_id, db)
    n = (
        db.query(VulnHistory)
        .filter(VulnHistory.asset_id == asset_id)
        .delete(synchronize_session=False)
    )
    db.commit()
    return BatchOperationResult(affected=n, message=f"已清空 {n} 条漏洞记录")


@router.delete("/ports/{port_id}")
def delete_port(port_id: int, db: Session = Depends(get_db)):
    row = db.query(PortHistory).filter(PortHistory.id == port_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="记录不存在")
    db.delete(row)
    db.commit()
    return {"ok": True}


@router.post("/ports/batch-delete", response_model=BatchOperationResult)
def batch_delete_ports(body: BatchDeletePortsRequest, db: Session = Depends(get_db)):
    if not body.port_ids:
        raise HTTPException(status_code=400, detail="请选择端口记录")
    rows = db.query(PortHistory).filter(PortHistory.id.in_(body.port_ids)).all()
    for row in rows:
        db.delete(row)
    db.commit()
    return BatchOperationResult(affected=len(rows), message=f"已删除 {len(rows)} 条端口记录")


@router.post("/vulns/batch-delete", response_model=BatchOperationResult)
def batch_delete_vulns(body: BatchDeleteVulnsRequest, db: Session = Depends(get_db)):
    if not body.vuln_ids:
        raise HTTPException(status_code=400, detail="请选择漏洞记录")
    rows = db.query(VulnHistory).filter(VulnHistory.id.in_(body.vuln_ids)).all()
    for row in rows:
        db.delete(row)
    db.commit()
    return BatchOperationResult(affected=len(rows), message=f"已删除 {len(rows)} 条漏洞记录")


# --- 存活探测 ---
@router.post("/assets/{asset_id}/probe", response_model=ProbeResult)
async def probe_asset(
    asset_id: int,
    body: ProbeRequest = ProbeRequest(),
    db: Session = Depends(get_db),
):
    asset = _get_asset_or_404(asset_id, db)
    success, rtt, message = await ping_ip(asset.ip, body.count)
    asset.is_alive = success
    asset.last_probe_at = datetime.utcnow()
    asset.updated_at = datetime.utcnow()
    db.commit()
    return ProbeResult(
        ip=asset.ip, success=success, response_time_ms=rtt, message=message
    )


@router.post("/assets/probe/filter", response_model=List[ProbeResult])
async def probe_by_filter(body: ProbeFilterRequest, db: Session = Depends(get_db)):
    """按当前筛选条件探测全部匹配资产（不分页）"""
    query = build_asset_query(
        db, body.q, body.department, body.c_segment, body.region, body.is_alive
    )
    assets = query.all()
    results: List[ProbeResult] = []
    for asset in assets:
        success, rtt, message = await ping_ip(asset.ip, body.count)
        asset.is_alive = success
        asset.last_probe_at = datetime.utcnow()
        asset.updated_at = datetime.utcnow()
        results.append(
            ProbeResult(
                ip=asset.ip,
                success=success,
                response_time_ms=rtt,
                message=message,
            )
        )
    db.commit()
    return results


@router.post("/assets/probe/batch", response_model=List[ProbeResult])
async def probe_batch(
    body: BatchProbeRequest = BatchProbeRequest(),
    db: Session = Depends(get_db),
):
    q = db.query(IntranetAsset)
    if body.asset_ids:
        q = q.filter(IntranetAsset.id.in_(body.asset_ids))
    assets = q.all()
    if not assets:
        return []

    results: List[ProbeResult] = []
    for asset in assets:
        success, rtt, message = await ping_ip(asset.ip, 2)
        asset.is_alive = success
        asset.last_probe_at = datetime.utcnow()
        asset.updated_at = datetime.utcnow()
        results.append(
            ProbeResult(
                ip=asset.ip,
                success=success,
                response_time_ms=rtt,
                message=message,
            )
        )
    db.commit()
    return results
