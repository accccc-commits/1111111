from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class VulnHistoryBase(BaseModel):
    title: str
    severity: Optional[str] = None
    description: Optional[str] = None
    status: str = "open"
    found_at: Optional[datetime] = None
    fixed_at: Optional[datetime] = None


class VulnHistoryCreate(VulnHistoryBase):
    pass


class VulnHistoryResponse(VulnHistoryBase):
    id: int
    asset_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class PortHistoryBase(BaseModel):
    port: int = Field(ge=1, le=65535)
    protocol: str = "tcp"
    service: Optional[str] = None
    version: Optional[str] = None
    state: str = "open"
    observed_at: Optional[datetime] = None
    source: Optional[str] = "manual"


class PortHistoryCreate(PortHistoryBase):
    pass


class PortHistoryResponse(PortHistoryBase):
    id: int
    asset_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class AssetBase(BaseModel):
    ip: str
    hostname: Optional[str] = None
    purpose: Optional[str] = None
    department: Optional[str] = None
    c_segment: Optional[str] = None
    region: Optional[str] = None
    owner: Optional[str] = None
    attributes: Optional[str] = None
    remark: Optional[str] = None


class AssetCreate(AssetBase):
    pass


class AssetUpdate(BaseModel):
    hostname: Optional[str] = None
    purpose: Optional[str] = None
    department: Optional[str] = None
    region: Optional[str] = None
    owner: Optional[str] = None
    attributes: Optional[str] = None
    remark: Optional[str] = None


class AssetResponse(AssetBase):
    id: int
    is_alive: Optional[bool] = None
    last_probe_at: Optional[datetime] = None
    port_count: int = 0
    vuln_count: int = 0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class AssetDetailResponse(AssetResponse):
    vuln_history: List[VulnHistoryResponse] = []
    port_history: List[PortHistoryResponse] = []


class PaginatedAssets(BaseModel):
    total: int
    items: List[AssetResponse]


class ProbeRequest(BaseModel):
    count: int = 2


class ProbeResult(BaseModel):
    ip: str
    success: bool
    response_time_ms: Optional[float] = None
    message: str


class BatchProbeRequest(BaseModel):
    asset_ids: Optional[List[int]] = None  # 为空则探测全部


class BatchDeleteRequest(BaseModel):
    asset_ids: List[int]


class BatchUpdateRequest(BaseModel):
    asset_ids: List[int]
    department: Optional[str] = None
    region: Optional[str] = None
    owner: Optional[str] = None
    purpose: Optional[str] = None


class BatchOperationResult(BaseModel):
    affected: int
    message: str = ""


class BatchDeletePortsRequest(BaseModel):
    port_ids: List[int]


class BatchDeleteVulnsRequest(BaseModel):
    vuln_ids: List[int]


class BatchDeleteRegionMappingsRequest(BaseModel):
    mapping_ids: List[int]


class ProbeFilterRequest(BaseModel):
    q: Optional[str] = None
    department: Optional[str] = None
    c_segment: Optional[str] = None
    region: Optional[str] = None
    is_alive: Optional[bool] = None
    count: int = 2


class AssetImportResult(BaseModel):
    created: int
    updated: int
    ports_added: int
    skipped: int
    skip_details: List[str] = []
    errors: List[str] = []


class CSegmentRegionItem(BaseModel):
    id: int
    c_segment: str
    region: str
    remark: Optional[str] = None

    class Config:
        from_attributes = True


class RegionImportResult(BaseModel):
    created: int
    updated: int
    total: int
    errors: List[str] = []
    assets_synced: Optional[int] = None


class OverviewStats(BaseModel):
    asset_total: int
    port_total: int
    c_segment_total: int
    region_mapping_total: int
    alive_total: int


class CSegmentStatItem(BaseModel):
    c_segment: str
    c_segment_display: str
    region: str
    asset_count: int
    port_count: int
    alive_count: int
