import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from .database import Base


class IntranetAsset(Base):
    __tablename__ = "intranet_assets"

    id = Column(Integer, primary_key=True, index=True)
    ip = Column(String(45), unique=True, index=True, nullable=False)
    hostname = Column(String(255), nullable=True)
    purpose = Column(String(512), nullable=True)  # 用途/干嘛的
    department = Column(String(128), index=True, nullable=True)  # 所属部门
    c_segment = Column(String(32), index=True, nullable=True)  # C 段，如 10.1.2
    region = Column(String(128), index=True, nullable=True)  # 归属区域（来自 C 段映射）
    owner = Column(String(128), nullable=True)  # 负责人
    attributes = Column(Text, nullable=True)  # 属性标签，逗号分隔或 JSON 文本
    remark = Column(Text, nullable=True)
    is_alive = Column(Boolean, nullable=True)  # 最近一次探测结果
    last_probe_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.datetime.utcnow,
        onupdate=datetime.datetime.utcnow,
    )

    vuln_history = relationship(
        "VulnHistory", back_populates="asset", cascade="all, delete-orphan"
    )
    port_history = relationship(
        "PortHistory", back_populates="asset", cascade="all, delete-orphan"
    )


class VulnHistory(Base):
    __tablename__ = "vuln_history"

    id = Column(Integer, primary_key=True, index=True)
    asset_id = Column(Integer, ForeignKey("intranet_assets.id"), nullable=False)
    title = Column(String(512), nullable=False)  # 漏洞名称/CVE
    severity = Column(String(32), nullable=True)  # critical/high/medium/low/info
    description = Column(Text, nullable=True)
    status = Column(String(32), default="open")  # open / fixed
    found_at = Column(DateTime, default=datetime.datetime.utcnow)
    fixed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    asset = relationship("IntranetAsset", back_populates="vuln_history")


class PortHistory(Base):
    __tablename__ = "port_history"

    id = Column(Integer, primary_key=True, index=True)
    asset_id = Column(Integer, ForeignKey("intranet_assets.id"), nullable=False)
    port = Column(Integer, nullable=False)
    protocol = Column(String(16), default="tcp")
    service = Column(String(128), nullable=True)
    version = Column(String(256), nullable=True)  # 服务版本 / Banner
    state = Column(String(32), default="open")
    observed_at = Column(DateTime, default=datetime.datetime.utcnow)
    source = Column(String(64), nullable=True)  # 记录来源：扫描/手工/探测
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    asset = relationship("IntranetAsset", back_populates="port_history")


class CSegmentRegion(Base):
    """C 段与区域/归属映射（CSV 导入维护）"""

    __tablename__ = "c_segment_regions"

    id = Column(Integer, primary_key=True, index=True)
    c_segment = Column(String(32), unique=True, index=True, nullable=False)  # 如 10.1.2
    region = Column(String(128), nullable=False)  # 区域/归属，如 合肥机房 / 生产区
    remark = Column(String(256), nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.datetime.utcnow,
        onupdate=datetime.datetime.utcnow,
    )
