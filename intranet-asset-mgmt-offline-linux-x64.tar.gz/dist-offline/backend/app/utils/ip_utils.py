import re

IP_PATTERN = re.compile(
    r"^(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}"
    r"(?:25[0-5]|2[0-4]\d|[01]?\d?\d)$"
)


def is_valid_ip(ip: str) -> bool:
    return bool(IP_PATTERN.match((ip or "").strip()))


def ip_to_c_segment(ip: str) -> str:
    """IPv4 -> C 段前缀，如 10.1.2.3 -> 10.1.2"""
    parts = (ip or "").strip().split(".")
    if len(parts) >= 3 and all(p.isdigit() for p in parts[:3]):
        return ".".join(parts[:3])
    return ""


def normalize_c_segment(value: str) -> str:
    """
    统一 C 段表示：10.1.2 / 10.1.2.0/24 / 10.1.2.0 -> 10.1.2
    """
    v = (value or "").strip()
    if not v:
        return ""
    v = v.split("/")[0].strip()
    parts = v.split(".")
    if len(parts) >= 3:
        try:
            return ".".join(str(int(p)) for p in parts[:3])
        except ValueError:
            return ""
    return v
