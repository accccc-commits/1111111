import asyncio
import re
from typing import Tuple, Optional


IP_PATTERN = re.compile(
    r"^(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}"
    r"(?:25[0-5]|2[0-4]\d|[01]?\d?\d)$"
)


def is_valid_ip(ip: str) -> bool:
    return bool(IP_PATTERN.match(ip.strip()))


async def ping_ip(ip: str, count: int = 2) -> Tuple[bool, Optional[float], str]:
    """ICMP 存活探测，返回 (是否存活, 平均时延ms, 说明)"""
    if not is_valid_ip(ip):
        return False, None, "无效的 IP 地址"

    cmd = ["ping", "-c", str(count), ip]
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await process.communicate()
        output = stdout.decode(errors="ignore")

        if process.returncode == 0:
            avg_ms = _parse_avg_ms(output)
            if avg_ms is not None:
                return True, avg_ms, f"存活，平均 {avg_ms:.1f} ms"
            return True, None, "存活"
        err = stderr.decode(errors="ignore").strip() or "无响应"
        return False, None, f"不可达: {err}"
    except Exception as e:
        return False, None, f"探测异常: {e}"


def _parse_avg_ms(output: str) -> Optional[float]:
    for line in output.splitlines():
        if "avg" in line.lower() or "平均" in line:
            # macOS: round-trip min/avg/max/stddev = 1.2/2.3/3.4/0.5 ms
            if "=" in line:
                part = line.split("=", 1)[1].strip()
                nums = re.findall(r"[\d.]+", part.replace("/", " "))
                if len(nums) >= 2:
                    return float(nums[1])
                if nums:
                    return float(nums[0])
    return None
