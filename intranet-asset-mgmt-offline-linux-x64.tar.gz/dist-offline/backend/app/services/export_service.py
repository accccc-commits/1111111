import csv
import io
from typing import List, Optional

from sqlalchemy.orm import Session

from ..models import IntranetAsset


def assets_to_csv(assets: List[IntranetAsset], port_counts: dict, vuln_counts: dict) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(
        [
            "IP",
            "C段",
            "归属",
            "主机名",
            "用途",
            "部门",
            "负责人",
            "属性",
            "端口数",
            "漏洞数",
            "存活",
            "备注",
        ]
    )
    for a in assets:
        alive = ""
        if a.is_alive is True:
            alive = "在线"
        elif a.is_alive is False:
            alive = "离线"
        writer.writerow(
            [
                a.ip,
                f"{a.c_segment}.0/24" if a.c_segment else "",
                a.region or "",
                a.hostname or "",
                a.purpose or "",
                a.department or "",
                a.owner or "",
                a.attributes or "",
                port_counts.get(a.id, 0),
                vuln_counts.get(a.id, 0),
                alive,
                a.remark or "",
            ]
        )
    return output.getvalue()


def c_segment_stats_to_csv(stats: list) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["C段", "归属区域", "IP数量", "开放端口数", "在线IP数"])
    for row in stats:
        writer.writerow(
            [
                row.get("c_segment_display") or row.get("c_segment"),
                row.get("region"),
                row.get("asset_count"),
                row.get("port_count"),
                row.get("alive_count"),
            ]
        )
    return output.getvalue()


def asset_ports_to_csv(ports: list, ip: str) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["IP", "端口", "协议", "服务", "版本", "状态", "来源", "观测时间"])
    for p in ports:
        writer.writerow(
            [
                ip,
                p.port,
                p.protocol or "",
                p.service or "",
                p.version or "",
                p.state or "",
                p.source or "",
                p.observed_at.isoformat() if p.observed_at else "",
            ]
        )
    return output.getvalue()
