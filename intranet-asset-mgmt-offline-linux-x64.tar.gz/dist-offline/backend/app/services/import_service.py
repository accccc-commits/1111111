from datetime import datetime
from typing import List, Optional

from sqlalchemy.orm import Session

from ..models import IntranetAsset, PortHistory
from ..utils.ip_utils import ip_to_c_segment
from .import_parser import ParsedRow, ImportPreview, parse_csv_content, parse_text_content, _norm_protocol
from .region_service import apply_c_segment_to_asset


def apply_import(
    db: Session,
    preview: ImportPreview,
    default_department: Optional[str] = None,
    default_owner: Optional[str] = None,
    skip_domain_only: bool = True,
) -> dict:
    """
    将解析结果写入数据库：按 IP 合并资产，端口写入历史。
    skip_domain_only: 跳过无法解析为 IP 的 EZ URL 行
    """
    created = 0
    updated = 0
    ports_added = 0
    skipped = 0
    skip_details: List[str] = []

    for row in preview.rows:
        if row.skip_reason or not row.ip:
            if row.skip_reason:
                if skip_domain_only:
                    skipped += 1
                    skip_details.append(row.skip_reason)
                    if row.raw_url:
                        skip_details[-1] = f"{row.skip_reason} | {row.raw_url[:100]}"
                continue
            skipped += 1
            continue

        asset = db.query(IntranetAsset).filter(IntranetAsset.ip == row.ip).first()
        is_new = asset is None

        if is_new:
            asset = IntranetAsset(
                ip=row.ip,
                hostname=row.hostname,
                purpose=row.purpose,
                department=row.department or default_department,
                owner=default_owner,
                attributes=row.attributes,
            )
            db.add(asset)
            db.flush()
            apply_c_segment_to_asset(asset, db)
            created += 1
        else:
            if row.hostname and not asset.hostname:
                asset.hostname = row.hostname
            if row.purpose:
                asset.purpose = _merge_text(asset.purpose, row.purpose)
            if row.attributes:
                asset.attributes = _merge_text(asset.attributes, row.attributes)
            if row.department and not asset.department:
                asset.department = row.department
            elif default_department and not asset.department:
                asset.department = default_department
            apply_c_segment_to_asset(asset, db)
            asset.updated_at = datetime.utcnow()
            updated += 1

        if row.port:
            proto = _norm_protocol(row.protocol)
            exists = (
                db.query(PortHistory)
                .filter(
                    PortHistory.asset_id == asset.id,
                    PortHistory.port == row.port,
                    PortHistory.protocol == proto,
                )
                .first()
            )
            if not exists:
                db.add(
                    PortHistory(
                        asset_id=asset.id,
                        port=row.port,
                        protocol=proto,
                        service=row.service,
                        version=row.version,
                        state=row.state or "open",
                        source=row.source,
                        observed_at=row.observed_at or datetime.utcnow(),
                    )
                )
                ports_added += 1
            else:
                if row.service:
                    exists.service = row.service
                if row.version:
                    exists.version = row.version
                if row.state:
                    exists.state = row.state
                exists.observed_at = row.observed_at or datetime.utcnow()
                exists.source = row.source or exists.source

    db.commit()
    return {
        "created": created,
        "updated": updated,
        "ports_added": ports_added,
        "skipped": skipped,
        "skip_details": skip_details[:50],
        "errors": preview.errors[:20],
    }


def _merge_text(old: Optional[str], new: str) -> str:
    if not old:
        return new
    if new in old:
        return old
    return f"{old}; {new}"


def load_preview_from_file(
    content: bytes,
    filename: str,
    import_type: str,
    text_mode: bool = False,
    resolve_dns: bool = False,
) -> ImportPreview:
    text = content.decode("utf-8-sig", errors="replace")
    ext = (filename or "").lower().split(".")[-1]
    if text_mode or ext == "txt":
        return parse_text_content(text, import_type, resolve_dns=resolve_dns)
    return parse_csv_content(text, import_type, resolve_dns=resolve_dns)
