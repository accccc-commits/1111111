from typing import List

from sqlalchemy import func
from sqlalchemy.orm import Session

from ..models import IntranetAsset, PortHistory, CSegmentRegion
from ..utils.ip_utils import ip_to_c_segment


def get_overview_stats(db: Session) -> dict:
    asset_total = db.query(IntranetAsset).count()
    port_total = db.query(PortHistory).count()
    c_segment_total = (
        db.query(IntranetAsset.c_segment)
        .filter(IntranetAsset.c_segment.isnot(None))
        .distinct()
        .count()
    )
    region_mapped = db.query(CSegmentRegion).count()
    alive = (
        db.query(IntranetAsset)
        .filter(IntranetAsset.is_alive == True)  # noqa: E712
        .count()
    )
    return {
        "asset_total": asset_total,
        "port_total": port_total,
        "c_segment_total": c_segment_total,
        "region_mapping_total": region_mapped,
        "alive_total": alive,
    }


def get_c_segment_stats(db: Session) -> List[dict]:
    """按 C 段统计：IP 数、端口数、在线数、归属区域"""
    # 先确保有 c_segment（内存回填未提交的仅用于统计展示）
    assets = db.query(IntranetAsset).all()
    segment_assets: dict[str, list] = {}
    for a in assets:
        seg = a.c_segment or ip_to_c_segment(a.ip)
        if not seg:
            continue
        segment_assets.setdefault(seg, []).append(a)

    port_by_asset = dict(
        db.query(PortHistory.asset_id, func.count(PortHistory.id))
        .group_by(PortHistory.asset_id)
        .all()
    )
    port_by_seg: dict[str, int] = {}
    for a in assets:
        seg = a.c_segment or ip_to_c_segment(a.ip)
        if not seg:
            continue
        port_by_seg[seg] = port_by_seg.get(seg, 0) + port_by_asset.get(a.id, 0)

    mappings = {
        m.c_segment: m.region for m in db.query(CSegmentRegion).all()
    }

    result = []
    for seg, alist in sorted(segment_assets.items()):
        alive = sum(1 for a in alist if a.is_alive is True)
        region = mappings.get(seg) or next(
            (a.region for a in alist if a.region), None
        )
        result.append(
            {
                "c_segment": seg,
                "c_segment_display": f"{seg}.0/24",
                "region": region or "未配置",
                "asset_count": len(alist),
                "port_count": port_by_seg.get(seg, 0),
                "alive_count": alive,
            }
        )
    result.sort(key=lambda x: (-x["port_count"], -x["asset_count"], x["c_segment"]))
    return result
