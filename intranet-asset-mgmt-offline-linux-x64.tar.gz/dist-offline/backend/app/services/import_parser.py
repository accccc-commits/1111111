"""EZ URL / IP+端口 导入解析"""
import csv
import io
import re
import socket
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Tuple
from urllib.parse import urlparse

IP_PATTERN = re.compile(
    r"^(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}"
    r"(?:25[0-5]|2[0-4]\d|[01]?\d?\d)$"
)

EZ_URL_COLUMNS = {
    "url": ["url", "URL", "网址", "链接"],
    "title": ["title", "Title", "标题", "网站标题", "页面标题"],
    "fingerprint": ["指纹", "fingerprint", "技术栈", "组件"],
    "score": ["评分", "score", "分数"],
    "status_code": ["返回码", "状态码", "status_code", "HTTP状态码"],
    "observed_at": ["添加时间", "发现时间", "时间", "observed_at"],
}

IP_PORT_COLUMNS = {
    "ip": ["ip", "IP", "地址", "主机", "主机IP", "host"],
    "port": ["port", "端口", "Port", "PORT"],
    "protocol": ["protocol", "协议", "Protocol", "PROTOCOL"],
    "service": ["service", "服务", "Service", "组件", "component", "应用"],
    "version": ["version", "版本", "Version", "服务版本", "banner", "Banner", "产品版本"],
    "title": ["title", "Title", "标题", "网站标题"],
    "purpose": ["purpose", "用途", "说明", "备注"],
    "department": ["department", "部门", "所属部门"],
    "hostname": ["hostname", "主机名", "域名", "domain"],
    "state": ["state", "状态", "端口状态"],
    "observed_at": ["observed_at", "发现时间", "扫描时间", "时间"],
}


@dataclass
class ParsedRow:
    ip: str
    port: Optional[int] = None
    protocol: str = "tcp"
    service: Optional[str] = None
    version: Optional[str] = None
    hostname: Optional[str] = None
    purpose: Optional[str] = None
    attributes: Optional[str] = None
    department: Optional[str] = None
    state: str = "open"
    source: str = "import"
    observed_at: Optional[datetime] = None
    raw_url: Optional[str] = None
    skip_reason: Optional[str] = None


@dataclass
class ImportPreview:
    rows: List[ParsedRow] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


def _pick(row: dict, keys: List[str]) -> Optional[str]:
    for k in keys:
        if k in row and row[k] is not None:
            v = str(row[k]).strip()
            if v and v.lower() != "nan":
                return v
    return None


def _parse_int(val: Optional[str]) -> Optional[int]:
    if not val:
        return None
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return None


def _parse_dt(val: Optional[str]) -> Optional[datetime]:
    if not val:
        return None
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y/%m/%d %H:%M",
        "%Y-%m-%d",
        "%Y/%m/%d",
    ):
        try:
            return datetime.strptime(val.strip(), fmt)
        except ValueError:
            continue
    return None


def resolve_host_ip(hostname: str) -> Optional[str]:
    try:
        return socket.gethostbyname(hostname.strip())
    except (socket.gaierror, OSError):
        return None


def host_port_from_url(
    url: str, resolve_dns: bool = False
) -> Tuple[Optional[str], Optional[int], Optional[str]]:
    """从 URL 解析 host、port、hostname"""
    u = url.strip()
    if not u:
        return None, None, None
    if "://" not in u:
        u = "http://" + u
    try:
        parsed = urlparse(u)
    except Exception:
        return None, None, None
    host = (parsed.hostname or "").strip()
    if not host:
        return None, None, None
    port = parsed.port
    if port is None:
        port = 443 if parsed.scheme == "https" else 80
    if IP_PATTERN.match(host):
        return host, port, None
    if resolve_dns:
        resolved = resolve_host_ip(host)
        if resolved and IP_PATTERN.match(resolved):
            return resolved, port, host
    return None, port, host


def _norm_protocol(val: Optional[str]) -> str:
    if not val:
        return "tcp"
    v = val.strip().lower()
    if v in ("tcp", "udp", "sctp"):
        return v
    if v in ("http", "https", "ssl", "tls", "ssh", "ftp", "smtp"):
        return "tcp"
    return v[:16]


def parse_ip_port_line(line: str) -> Optional[ParsedRow]:
    """支持 10.0.0.1:8080 或 10.0.0.1,8080,tcp,http"""
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if "://" in line:
        ip, port, hostname = host_port_from_url(line)
        if ip:
            return ParsedRow(ip=ip, port=port, hostname=hostname, raw_url=line, source="ez-url")
        return ParsedRow(
            ip="",
            hostname=hostname,
            skip_reason=f"URL 无内网 IP: {line[:80]}",
            raw_url=line,
        )
    if ":" in line and "," not in line.split(":")[0]:
        parts = line.rsplit(":", 1)
        if len(parts) == 2 and IP_PATTERN.match(parts[0].strip()):
            ip = parts[0].strip()
            port = _parse_int(parts[1].strip())
            return ParsedRow(ip=ip, port=port, source="ip-port")
    parts = [p.strip() for p in line.split(",")]
    if parts and IP_PATTERN.match(parts[0]):
        ip = parts[0]
        port = _parse_int(parts[1]) if len(parts) > 1 else None
        protocol = _norm_protocol(parts[2] if len(parts) > 2 else "tcp")
        service = parts[3] if len(parts) > 3 else None
        version = parts[4] if len(parts) > 4 else None
        purpose = parts[5] if len(parts) > 5 else None
        return ParsedRow(
            ip=ip,
            port=port,
            protocol=protocol,
            service=service,
            version=version,
            purpose=purpose,
            source="ip-port",
        )
    return None


def normalize_header(name: str) -> str:
    return (name or "").strip().lstrip("\ufeff")


def _row_from_dict(data: dict, import_type: str, resolve_dns: bool = False) -> ParsedRow:
    if import_type == "ez-url":
        url = _pick(data, EZ_URL_COLUMNS["url"])
        if not url:
            return ParsedRow(ip="", skip_reason="缺少 URL")
        ip, port, hostname = host_port_from_url(url, resolve_dns=resolve_dns)
        title = _pick(data, EZ_URL_COLUMNS["title"])
        fp = _pick(data, EZ_URL_COLUMNS["fingerprint"])
        score = _pick(data, EZ_URL_COLUMNS["score"])
        code = _pick(data, EZ_URL_COLUMNS["status_code"])
        attrs_parts = []
        if fp:
            attrs_parts.append(fp)
        if score:
            attrs_parts.append(f"评分:{score}")
        if code:
            attrs_parts.append(f"状态码:{code}")
        if url:
            attrs_parts.append(f"来源URL:{url[:200]}")
        observed = _parse_dt(_pick(data, EZ_URL_COLUMNS["observed_at"]))
        if not ip:
            return ParsedRow(
                ip="",
                hostname=hostname,
                port=port,
                purpose=title,
                attributes="; ".join(attrs_parts) if attrs_parts else None,
                source="ez-url",
                observed_at=observed,
                raw_url=url,
                skip_reason=f"URL 未解析到 IP（域名: {hostname}）",
            )
        return ParsedRow(
            ip=ip,
            port=port,
            hostname=hostname,
            purpose=title,
            attributes="; ".join(attrs_parts) if attrs_parts else None,
            service=fp,
            source="ez-url",
            observed_at=observed,
            raw_url=url,
        )
    # ip-port
    ip = _pick(data, IP_PORT_COLUMNS["ip"])
    if not ip or not IP_PATTERN.match(ip):
        return ParsedRow(ip="", skip_reason=f"无效 IP: {ip or '(空)'}")
    port = _parse_int(_pick(data, IP_PORT_COLUMNS["port"]))
    service = _pick(data, IP_PORT_COLUMNS["service"])
    version = _pick(data, IP_PORT_COLUMNS["version"])
    state = _pick(data, IP_PORT_COLUMNS["state"]) or "open"
    observed = _parse_dt(_pick(data, IP_PORT_COLUMNS["observed_at"]))
    return ParsedRow(
        ip=ip,
        port=port,
        protocol=_norm_protocol(_pick(data, IP_PORT_COLUMNS["protocol"])),
        service=service,
        version=version,
        hostname=_pick(data, IP_PORT_COLUMNS["hostname"]),
        purpose=_pick(data, IP_PORT_COLUMNS["purpose"]) or _pick(data, IP_PORT_COLUMNS["title"]),
        department=_pick(data, IP_PORT_COLUMNS["department"]),
        state=state,
        source="ip-port",
        observed_at=observed,
    )


def parse_csv_content(
    content: str, import_type: str, resolve_dns: bool = False
) -> ImportPreview:
    preview = ImportPreview()
    try:
        reader = csv.DictReader(io.StringIO(content))
        if not reader.fieldnames:
            preview.errors.append("CSV 无表头")
            return preview
        reader.fieldnames = [normalize_header(h) for h in reader.fieldnames]
        for i, row in enumerate(reader, start=2):
            normalized = {normalize_header(k): v for k, v in row.items()}
            parsed = _row_from_dict(normalized, import_type, resolve_dns=resolve_dns)
            if parsed.skip_reason and not parsed.ip:
                preview.rows.append(parsed)
            elif parsed.ip:
                preview.rows.append(parsed)
            else:
                preview.errors.append(f"第 {i} 行无法解析")
    except Exception as e:
        preview.errors.append(str(e))
    return preview


def parse_text_content(
    text: str, import_type: str, resolve_dns: bool = False
) -> ImportPreview:
    """纯文本：每行一条 URL 或 IP:端口"""
    preview = ImportPreview()
    for i, line in enumerate(text.splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        if import_type == "ez-url" and ("http://" in line or "https://" in line or "://" in line):
            ip, port, hostname = host_port_from_url(line, resolve_dns=resolve_dns)
            if ip:
                preview.rows.append(
                    ParsedRow(ip=ip, port=port, hostname=hostname, raw_url=line, source="ez-url")
                )
            else:
                preview.rows.append(
                    ParsedRow(
                        ip="",
                        hostname=hostname,
                        raw_url=line,
                        skip_reason=f"第 {i} 行: 未解析到 IP",
                    )
                )
            continue
        parsed = parse_ip_port_line(line)
        if parsed:
            preview.rows.append(parsed)
        else:
            preview.errors.append(f"第 {i} 行无法解析: {line[:60]}")
    return preview
