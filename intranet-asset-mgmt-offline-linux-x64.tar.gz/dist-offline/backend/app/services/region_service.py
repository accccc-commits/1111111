"""C 段区域映射导入与资产归属同步"""
import csv
import io
from typing import List, Optional, Tuple

from sqlalchemy.orm import Session

from ..models import IntranetAsset, CSegmentRegion
from ..utils.ip_utils import ip_to_c_segment, normalize_c_segment

REGION_COLUMNS = {
    "c_segment": ["c_segment", "C段", "c段", "网段", "网段地址", "segment", "C段地址"],
    "region": ["region", "区域", "归属", "所属区域", "机房", "位置", "area", "归属区域"],
    "remark": ["remark", "备注", "说明", "描述"],
}


def _pick(row: dict, keys: List[str]) -> Optional[str]:
    for k in keys:
        if k in row and row[k] is not None:
            v = str(row[k]).strip()
            if v and v.lower() != "nan":
                return v
    return None


def parse_region_csv(content: str) -> Tuple[List[dict], List[str]]:
    errors: List[str] = []
    rows: List[dict] = []
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        return [], ["CSV 无表头"]
    headers = [h.strip().lstrip("\ufeff") for h in reader.fieldnames]
    for i, raw in enumerate(reader, start=2):
        row = {headers[j]: raw[reader.fieldnames[j]] for j in range(len(headers))}
        c_raw = _pick(row, REGION_COLUMNS["c_segment"])
        region = _pick(row, REGION_COLUMNS["region"])
        if not c_raw or not region:
            errors.append(f"第 {i} 行缺少 C 段或区域")
            continue
        c_seg = normalize_c_segment(c_raw)
        if not c_seg:
            errors.append(f"第 {i} 行 C 段格式无效: {c_raw}")
            continue
        rows.append(
            {
                "c_segment": c_seg,
                "region": region,
                "remark": _pick(row, REGION_COLUMNS["remark"]),
            }
        )
    return rows, errors


def import_region_mappings(db: Session, mappings: List[dict]) -> dict:
    created = updated = 0
    for m in mappings:
        existing = (
            db.query(CSegmentRegion)
            .filter(CSegmentRegion.c_segment == m["c_segment"])
            .first()
        )
        if existing:
            existing.region = m["region"]
            if m.get("remark"):
                existing.remark = m["remark"]
            updated += 1
        else:
            db.add(CSegmentRegion(**m))
            created += 1
    db.commit()
    return {"created": created, "updated": updated, "total": len(mappings)}


def lookup_region(db: Session, c_segment: str) -> Optional[str]:
    if not c_segment:
        return None
    row = (
        db.query(CSegmentRegion.region)
        .filter(CSegmentRegion.c_segment == c_segment)
        .first()
    )
    return row[0] if row else None


def apply_c_segment_to_asset(asset: IntranetAsset, db: Session) -> None:
    """根据 IP 写入 C 段，并按映射表填充归属区域"""
    c_seg = ip_to_c_segment(asset.ip)
    if c_seg:
        asset.c_segment = c_seg
        region = lookup_region(db, c_seg)
        if region:
            asset.region = region


def sync_all_asset_regions(db: Session) -> dict:
    """为全部资产回填 C 段与区域"""
    assets = db.query(IntranetAsset).all()
    updated = 0
    for asset in assets:
        old_c, old_r = asset.c_segment, asset.region
        apply_c_segment_to_asset(asset, db)
        if asset.c_segment != old_c or asset.region != old_r:
            updated += 1
    db.commit()
    return {"assets_total": len(assets), "assets_updated": updated}
