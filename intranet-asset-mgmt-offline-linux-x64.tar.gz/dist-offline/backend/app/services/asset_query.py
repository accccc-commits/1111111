"""资产列表查询与计数复用"""
from typing import Optional, Tuple, List, Dict

from sqlalchemy import or_, func
from sqlalchemy.orm import Session

from ..models import IntranetAsset, PortHistory, VulnHistory


def build_asset_query(
    db: Session,
    q: Optional[str] = None,
    department: Optional[str] = None,
    c_segment: Optional[str] = None,
    region: Optional[str] = None,
    is_alive: Optional[bool] = None,
):
    query = db.query(IntranetAsset)
    if q:
        like = f"%{q.strip()}%"
        query = query.filter(
            or_(
                IntranetAsset.ip.like(like),
                IntranetAsset.hostname.like(like),
                IntranetAsset.purpose.like(like),
                IntranetAsset.department.like(like),
                IntranetAsset.c_segment.like(like),
                IntranetAsset.region.like(like),
                IntranetAsset.attributes.like(like),
                IntranetAsset.owner.like(like),
            )
        )
    if department:
        query = query.filter(IntranetAsset.department == department)
    if c_segment:
        query = query.filter(IntranetAsset.c_segment == c_segment)
    if region:
        query = query.filter(IntranetAsset.region == region)
    if is_alive is not None:
        query = query.filter(IntranetAsset.is_alive == is_alive)
    return query


def get_counts_for_assets(
    db: Session, asset_ids: List[int]
) -> Tuple[Dict[int, int], Dict[int, int]]:
    if not asset_ids:
        return {}, {}
    port_counts = dict(
        db.query(PortHistory.asset_id, func.count(PortHistory.id))
        .filter(PortHistory.asset_id.in_(asset_ids))
        .group_by(PortHistory.asset_id)
        .all()
    )
    vuln_counts = dict(
        db.query(VulnHistory.asset_id, func.count(VulnHistory.id))
        .filter(VulnHistory.asset_id.in_(asset_ids))
        .group_by(VulnHistory.asset_id)
        .all()
    )
    return port_counts, vuln_counts


def assets_to_response_list(db: Session, assets: list):
    from ..schemas import AssetResponse

    ids = [a.id for a in assets]
    port_counts, vuln_counts = get_counts_for_assets(db, ids)
    result = []
    for a in assets:
        data = AssetResponse.model_validate(a)
        data.port_count = port_counts.get(a.id, 0)
        data.vuln_count = vuln_counts.get(a.id, 0)
        result.append(data)
    return result
