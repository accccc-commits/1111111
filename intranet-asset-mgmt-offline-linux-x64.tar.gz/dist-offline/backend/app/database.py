import os
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# 数据目录：内网部署时通过 INTRANET_DATA_DIR 指定（存放 SQLite）
_BACKEND_ROOT = Path(__file__).resolve().parent.parent
_DATA_DIR = Path(os.environ.get("INTRANET_DATA_DIR", str(_BACKEND_ROOT)))
_DATA_DIR.mkdir(parents=True, exist_ok=True)
_DB_FILE = _DATA_DIR / "intranet_assets.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///{_DB_FILE}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
