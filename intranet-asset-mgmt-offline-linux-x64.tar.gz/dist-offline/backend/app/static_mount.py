"""生产环境挂载前端静态资源（内网单进程部署）"""
import os
from pathlib import Path
from typing import Optional

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles


def _static_dir() -> Optional[Path]:
    env = os.environ.get("INTRANET_STATIC_DIR")
    if env:
        p = Path(env)
        if p.is_dir() and (p / "index.html").exists():
            return p
    candidates = [
        Path(__file__).resolve().parent.parent.parent / "frontend_dist",
        Path(__file__).resolve().parent.parent / "frontend_dist",
    ]
    for p in candidates:
        if p.is_dir() and (p / "index.html").exists():
            return p
    return None


def mount_frontend(app: FastAPI) -> bool:
    static_dir = _static_dir()
    if not static_dir:
        return False

    # html=True：前端路由回退到 index.html；/api 路由已先注册，不会被覆盖
    app.mount(
        "/",
        StaticFiles(directory=str(static_dir), html=True),
        name="frontend",
    )
    return True
