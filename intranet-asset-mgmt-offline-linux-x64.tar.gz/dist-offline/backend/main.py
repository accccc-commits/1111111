import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

from app.database import Base, engine
from app.api.routes import router
from app.static_mount import mount_frontend
from sqlalchemy import inspect, text


def migrate_db():
    """轻量迁移：为已有库补字段/表"""
    insp = inspect(engine)
    tables = insp.get_table_names()
    with engine.begin() as conn:
        if "port_history" in tables:
            cols = {c["name"] for c in insp.get_columns("port_history")}
            if "version" not in cols:
                conn.execute(
                    text("ALTER TABLE port_history ADD COLUMN version VARCHAR(256)")
                )
        if "intranet_assets" in tables:
            cols = {c["name"] for c in insp.get_columns("intranet_assets")}
            if "c_segment" not in cols:
                conn.execute(
                    text("ALTER TABLE intranet_assets ADD COLUMN c_segment VARCHAR(32)")
                )
            if "region" not in cols:
                conn.execute(
                    text("ALTER TABLE intranet_assets ADD COLUMN region VARCHAR(128)")
                )


Base.metadata.create_all(bind=engine)
migrate_db()

app = FastAPI(
    title="内网资产管理",
    description="内网 IP 资产登记、查询、存活探测与历史漏洞/端口记录",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api")

_has_ui = mount_frontend(app)
if _has_ui:
    print("[内网资产管理] 已加载前端静态页面（生产模式）")


if __name__ == "__main__":
    host = os.environ.get("INTRANET_HOST", "0.0.0.0")
    port = int(os.environ.get("INTRANET_PORT", "8010"))
    reload = os.environ.get("INTRANET_RELOAD", "").lower() in ("1", "true", "yes")
    uvicorn.run("main:app", host=host, port=port, reload=reload)
