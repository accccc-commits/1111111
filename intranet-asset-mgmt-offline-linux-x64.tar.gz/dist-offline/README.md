# 内网资产管理

面向客户内网的轻量 IP 资产管理：登记用途、部门、属性，支持查询与 ICMP 存活探测，并记录**历史漏洞**与**历史开放端口**。

不包含客户管理、风险矩阵、供应链、凭据泄露等模块。

## 功能

| 模块 | 说明 |
|------|------|
| 资产登记 | IP、主机名、用途、部门、负责人、属性、备注 |
| 资产查询 | 模糊搜索；按 C 段、归属、部门、存活筛选 |
| C 段 / 归属 | 自动 C 段；CSV 导入 C 段→区域映射并同步到资产 |
| 存活探测 | 单台 / 选中 / **当前筛选结果** / 全部 |
| 批量操作 | **批量删除**、**批量编辑**（归属/部门/负责人/用途） |
| 导出 | 资产列表 CSV、C 段统计 CSV、单 IP 端口 CSV |
| 历史漏洞 | 增删、**批量删除**、**清空** |
| 历史端口 | 增删、**批量删除**、**清空**、导出 |
| 统计 | C 段维度：IP 数、**端口总数**、在线数 |
| 批量导入 | EZ URL、IP+端口（见 `templates/`） |

## 启动

### 内网 Linux 离线一键部署（推荐给客户）

客户环境**不出网**，详见 **[DEPLOY-OFFLINE.md](./DEPLOY-OFFLINE.md)**。

```bash
# 在有网的 Linux 打包机执行一次
bash scripts/prepare-offline-package.sh

# 内网服务器
tar -xzf intranet-asset-mgmt-offline-linux-x64.tar.gz
cd intranet-asset-mgmt-offline-linux-x64
bash scripts/install-offline.sh
bash scripts/start.sh
```

浏览器访问：**http://服务器IP:8010**（单端口，含前后端）

### 本地开发（Mac / 有网）

```bash
# 后端
cd backend && pip install -r requirements.txt && python main.py

# 前端
cd frontend && npm install && npm run dev
```

开发时前端：**http://localhost:5180**，API 代理到 8010。

## 技术栈

- 后端：FastAPI + SQLAlchemy + SQLite
- 前端：Vue 3 + Element Plus + Vite

## 说明

- 存活探测依赖本机可执行 `ping`，需对目标网段有 ICMP 权限。
- 历史漏洞/端口为**手工或导入后归档**，不做自动漏洞扫描或全端口扫描（可按需后续扩展）。

### 批量导入

- **EZ URL**：与 EZ 导出一致，列名支持 `URL`、`Title`、`指纹`、`评分`、`返回码`、`添加时间`（或英文 url/title 等）。从 URL 解析 IP 与端口；**仅含域名的 URL 会跳过**（内网场景请使用带 IP 的 URL）。
- **IP + 端口**：CSV 列 `IP`、`端口`、`协议`、`服务`、`版本`（及可选 `用途`、`部门`）；或 TXT 每行 `10.0.0.1:8080` / `10.0.0.1,8080,tcp,nginx,1.20.1`。
- 模板：`templates/ez_url_import_template.csv`、`templates/ip_port_import_template.csv`、`templates/c_segment_region_template.csv`。

### 页面入口

- **资产列表**：新增、导入、导出、批量编辑/删除、探测
- **资产详情**：编辑、删除资产；端口/漏洞批量删、清空、导出端口
- **C段统计**：汇总与按 C 段端口统计
- **归属映射**：管理 C 段→区域 CSV 映射，批量删除映射
