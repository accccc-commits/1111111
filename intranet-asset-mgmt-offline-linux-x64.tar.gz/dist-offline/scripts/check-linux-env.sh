#!/usr/bin/env bash
# 客户内网 Linux 上运行：检查架构 / glibc / Python 是否与离线包匹配
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="${PYTHON:-python3}"
WHEELS="$ROOT/vendor/wheels"

echo "========== 内网资产管理 - 环境自检 =========="
echo "主机: $(uname -srmo 2>/dev/null || uname -a)"
ARCH="$(uname -m)"
echo "CPU 架构: $ARCH"
if [[ "$ARCH" != "x86_64" && "$ARCH" != "amd64" ]]; then
  echo "❌ 离线包仅支持 64 位 x86（x86_64）。当前为 $ARCH，需换 amd64 机器或重新打对应架构包。"
  exit 1
fi
echo "✓ 架构 x86_64"

if command -v ldd &>/dev/null; then
  GLIBC_VER="$(ldd --version 2>&1 | head -1)"
  echo "glibc: $GLIBC_VER"
  # manylinux2014 需 glibc >= 2.17；部分 wheel 若仅 2_28 标签则需 >= 2.28
  if ldd --version 2>&1 | grep -qE '2\.(1[0-6]|[0-9])\b'; then
    echo "⚠ glibc 偏旧（如 CentOS 7）。若 pip 报不兼容，请升级系统或使用 Python 3.11 + 对应离线包。"
  fi
fi

if ! command -v "$PYTHON" &>/dev/null; then
  echo "❌ 未找到 $PYTHON"
  exit 1
fi

"$PYTHON" - <<'PY'
import sys, platform
print(f"Python: {sys.version}")
print(f"可执行文件: {sys.executable}")
tag = f"{sys.version_info.major}{sys.version_info.minor}"
if sys.version_info < (3, 10):
    print("❌ 需要 Python 3.10+")
    sys.exit(1)
print(f"✓ Python 标签 cp{tag}（离线 wheel 须与此一致）")
PY

if [[ -d "$WHEELS" ]]; then
  COUNT=$(ls -1 "$WHEELS"/*.whl 2>/dev/null | wc -l | tr -d ' ')
  echo "vendor/wheels 数量: $COUNT"
  PY_TAG="$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}{sys.version_info.minor}")')"
  CP_COUNT=$(ls -1 "$WHEELS"/cp${PY_TAG}-*.whl 2>/dev/null | wc -l | tr -d ' ')
  if [[ "$CP_COUNT" == "0" ]]; then
    echo "❌ wheels 中没有 cp${PY_TAG} 包，与当前 Python 不匹配，需用 PY_TAG=${PY_TAG} 重新打离线包"
    exit 1
  fi
  echo "✓ 找到 cp${PY_TAG} 相关 wheel ($CP_COUNT 个)"
else
  echo "⚠ 未找到 $WHEELS（可能尚未解压完整离线包）"
fi

echo "=========================================="
echo "建议: bash scripts/install-offline.sh && bash scripts/start.sh"
