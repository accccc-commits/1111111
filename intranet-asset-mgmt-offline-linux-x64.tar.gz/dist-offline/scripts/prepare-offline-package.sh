#!/usr/bin/env bash
# 【在可联网的 Linux x86_64 上执行】生成内网离线安装包，再拷贝到客户环境
# 客户环境只需: python3 + bash，无需 Node、无需外网
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
PY_TAG="${PY_TAG:-$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}{sys.version_info.minor}")')}"
PLATFORM="${PLATFORM:-manylinux2014_x86_64}"
OUT_DIR="$ROOT/dist-offline"
PKG_NAME="intranet-asset-mgmt-offline-linux-x64"
ARCHIVE="$ROOT/${PKG_NAME}.tar.gz"

echo "=== 1/4 下载 Python 离线 wheel（Linux x64, py${PY_TAG}）==="
mkdir -p "$ROOT/vendor/wheels"
"$PYTHON" -m pip install --upgrade pip wheel -q
"$PYTHON" -m pip download -r "$ROOT/backend/requirements.txt" \
  -d "$ROOT/vendor/wheels" \
  --platform "$PLATFORM" \
  --python-version "$PY_TAG" \
  --only-binary=:all: 2>/dev/null || \
"$PYTHON" -m pip download -r "$ROOT/backend/requirements.txt" \
  -d "$ROOT/vendor/wheels" \
  --platform "$PLATFORM" \
  --python-version "$PY_TAG"

echo "=== 2/4 构建前端（需 Node，仅打包机执行一次）==="
if ! command -v npm &>/dev/null; then
  echo "错误: 需要 npm 构建前端。请在打包机安装 Node 18+"
  exit 1
fi
cd "$ROOT/frontend"
if [[ ! -d node_modules ]]; then
  npm ci
fi
npm run build
cd "$ROOT"

echo "=== 3/4 组装离线目录 ===="
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"
rsync -a \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude '.venv' \
  --exclude 'node_modules' \
  --exclude 'dist-offline' \
  --exclude 'run' \
  --exclude 'data' \
  --exclude 'frontend/dist' \
  "$ROOT/backend" "$OUT_DIR/"
rsync -a "$ROOT/frontend/dist/" "$OUT_DIR/frontend_dist/"
rsync -a "$ROOT/vendor/wheels" "$OUT_DIR/vendor/"
rsync -a "$ROOT/scripts" "$OUT_DIR/"
rsync -a "$ROOT/templates" "$OUT_DIR/" 2>/dev/null || true
cp "$ROOT/config.env.example" "$OUT_DIR/"
cp "$ROOT/README.md" "$OUT_DIR/" 2>/dev/null || true
cp "$ROOT/DEPLOY-OFFLINE.md" "$OUT_DIR/" 2>/dev/null || true
chmod +x "$OUT_DIR/scripts/"*.sh

echo "=== 4/4 打包 tar.gz ===="
tar -czf "$ARCHIVE" -C "$(dirname "$OUT_DIR")" "$(basename "$OUT_DIR")"
echo ""
echo "完成: $ARCHIVE"
echo "拷贝到内网服务器后:"
echo "  tar -xzf ${PKG_NAME}.tar.gz"
echo "  cd ${PKG_NAME}"
echo "  bash scripts/install-offline.sh"
echo "  bash scripts/start.sh"
