#!/usr/bin/env bash
# 【在可联网的 Linux x86_64 上执行】生成内网离线安装包，再拷贝到客户环境
# 客户环境只需: python3 + bash，无需 Node、无需外网
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
PY_TAG="${PY_TAG:-$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}{sys.version_info.minor}")')}"
PLATFORM="${PLATFORM:-manylinux2014_x86_64}"
OUT_DIR="$ROOT/dist-offline"
PKG_NAME="intranet-asset-mgmt-offline-linux-x64"
ARCHIVE="$ROOT/${PKG_NAME}.tar.gz"

# 必须在 Linux x86_64 上下载 wheel（Mac/ARM 上 --platform 可能混入不兼容标签）
UNAME_S="$(uname -s 2>/dev/null || echo unknown)"
UNAME_M="$(uname -m 2>/dev/null || echo unknown)"
if [[ "$UNAME_S" != "Linux" || "$UNAME_M" != "x86_64" ]]; then
  echo "警告: 当前为 ${UNAME_S}/${UNAME_M}，建议在 Linux x86_64 或 Docker 中打包，否则客户机可能报 wheel 不兼容"
  echo "  docker run --rm --platform linux/amd64 -v \"\$(pwd):/app\" -w /app python:3.13-bookworm bash scripts/prepare-offline-package.sh"
fi

echo "=== 1/4 下载 Python 离线 wheel（Linux x64, py${PY_TAG}）==="
rm -rf "$ROOT/vendor/wheels"
mkdir -p "$ROOT/vendor/wheels"
"$PYTHON" -m pip install --upgrade pip wheel -q
# 优先 manylinux2014（兼容 CentOS 7+ / 麒麟等老 glibc）；避免拉取仅 manylinux_2_28 的可选包
"$PYTHON" -m pip download -r "$ROOT/backend/requirements.txt" \
  -d "$ROOT/vendor/wheels" \
  --platform "$PLATFORM" \
  --python-version "$PY_TAG" \
  --implementation cp \
  --abi "cp${PY_TAG}" \
  --only-binary=:all:

echo "校验 wheel..."
"$PYTHON" - <<PY
import sys
from pathlib import Path
wheels = list(Path("$ROOT/vendor/wheels").glob("*.whl"))
need = {"uvicorn", "fastapi", "sqlalchemy", "pydantic"}
found = set()
for w in wheels:
    n = w.name.lower()
    for k in need:
        if n.startswith(k.replace("_", "-")) or n.startswith(k):
            found.add(k)
missing = need - found
if missing:
    raise SystemExit(f"缺少 wheel: {missing}")
# 提醒仅 2_28 的包（老系统可能装不上）
bad = [w.name for w in wheels if "manylinux_2_28" in w.name and "manylinux2014" not in w.name]
if bad:
    print("注意: 以下 wheel 仅 manylinux_2_28，CentOS7 等老系统可能不兼容:")
    for b in bad:
        print(" ", b)
print(f"共 {len(wheels)} 个 wheel，核心依赖齐全")
PY

echo "=== 2/4 构建前端（需 Node，仅打包机执行一次）==="
if ! command -v npm &>/dev/null; then
  echo "错误: 需要 npm 构建前端。请在打包机安装 Node 18+"
  exit 1
fi
cd "$ROOT/frontend"
if [[ ! -d node_modules ]]; then
  npm ci
fi
npm run build
cd "$ROOT"

echo "=== 3/4 组装离线目录 ===="
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"
rsync -a \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude '.venv' \
  --exclude 'node_modules' \
  --exclude 'dist-offline' \
  --exclude 'run' \
  --exclude 'data' \
  --exclude 'frontend/dist' \
  "$ROOT/backend" "$OUT_DIR/"
rsync -a "$ROOT/frontend/dist/" "$OUT_DIR/frontend_dist/"
rsync -a "$ROOT/vendor/wheels" "$OUT_DIR/vendor/"
rsync -a "$ROOT/scripts" "$OUT_DIR/"
rsync -a "$ROOT/templates" "$OUT_DIR/" 2>/dev/null || true
cp "$ROOT/config.env.example" "$OUT_DIR/"
cp "$ROOT/README.md" "$OUT_DIR/" 2>/dev/null || true
cp "$ROOT/DEPLOY-OFFLINE.md" "$OUT_DIR/" 2>/dev/null || true
chmod +x "$OUT_DIR/scripts/"*.sh

echo "=== 4/4 打包 tar.gz ===="
tar -czf "$ARCHIVE" -C "$(dirname "$OUT_DIR")" "$(basename "$OUT_DIR")"
echo ""
echo "完成: $ARCHIVE"
echo "拷贝到内网服务器后:"
echo "  tar -xzf ${PKG_NAME}.tar.gz"
echo "  cd ${PKG_NAME}"
echo "  bash scripts/install-offline.sh"
echo "  bash scripts/start.sh"
