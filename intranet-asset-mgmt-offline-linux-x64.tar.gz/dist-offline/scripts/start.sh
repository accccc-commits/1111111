#!/usr/bin/env bash
# 内网资产管理 - 一键启动（Linux，无需 Node，无需外网）
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ -f "$ROOT/config.env" ]]; then
  set -a
  # shellcheck source=/dev/null
  source "$ROOT/config.env"
  set +a
fi

: "${INTRANET_HOST:=0.0.0.0}"
: "${INTRANET_PORT:=8010}"
: "${INTRANET_RELOAD:=false}"

export INTRANET_DATA_DIR="${INTRANET_DATA_DIR:-$ROOT/data}"
export INTRANET_STATIC_DIR="${INTRANET_STATIC_DIR:-$ROOT/frontend_dist}"
mkdir -p "$INTRANET_DATA_DIR"

VENV="$ROOT/.venv"
if [[ ! -x "$VENV/bin/python" ]]; then
  echo "未找到 Python 虚拟环境，请先执行: bash scripts/install-offline.sh"
  exit 1
fi

if [[ ! -f "$INTRANET_STATIC_DIR/index.html" ]]; then
  echo "警告: 未找到 $INTRANET_STATIC_DIR/index.html"
  echo "请使用完整离线安装包，或在有网环境执行 scripts/prepare-offline-package.sh 后重新打包"
fi

PID_FILE="$ROOT/run/intranet-asset.pid"
LOG_FILE="$ROOT/run/app.log"
mkdir -p "$ROOT/run"

if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo "服务已在运行 (PID $(cat "$PID_FILE"))，访问: http://127.0.0.1:${INTRANET_PORT}"
  exit 0
fi

echo "启动内网资产管理..."
echo "  数据目录: $INTRANET_DATA_DIR"
echo "  访问地址: http://${INTRANET_HOST}:${INTRANET_PORT} （本机可用 127.0.0.1）"

cd "$ROOT/backend"
nohup "$VENV/bin/python" -m uvicorn main:app \
  --host "$INTRANET_HOST" \
  --port "$INTRANET_PORT" \
  >>"$LOG_FILE" 2>&1 &
echo $! >"$PID_FILE"

sleep 1
if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
  echo "启动成功 PID=$(cat "$PID_FILE")，日志: $LOG_FILE"
else
  echo "启动失败，请查看日志: $LOG_FILE"
  tail -20 "$LOG_FILE" 2>/dev/null || true
  exit 1
fi
