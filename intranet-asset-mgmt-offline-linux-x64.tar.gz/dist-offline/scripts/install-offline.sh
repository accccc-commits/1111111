#!/usr/bin/env bash
# 目标 Linux 内网环境：仅用本目录自带的 wheel 包安装，不访问外网
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
WHEELS="$ROOT/vendor/wheels"
REQ="$ROOT/backend/requirements.txt"
VENV="$ROOT/.venv"

if ! command -v "$PYTHON" &>/dev/null; then
  echo "错误: 未找到 python3，请先安装 Python 3.10+（系统 ISO 或离线 rpm 包）"
  exit 1
fi

PY_VER="$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
echo "使用 Python $PY_VER: $($PYTHON -c 'import sys; print(sys.executable)')"

if [[ ! -d "$WHEELS" ]] || [[ -z "$(ls -A "$WHEELS" 2>/dev/null || true)" ]]; then
  echo "错误: 未找到 vendor/wheels 离线依赖包"
  echo "请在可联网的 Linux 上执行 scripts/prepare-offline-package.sh 生成完整安装包"
  exit 1
fi

if [[ ! -f "$REQ" ]]; then
  echo "错误: 缺少 $REQ"
  exit 1
fi

echo "创建虚拟环境 $VENV ..."
"$PYTHON" -m venv "$VENV"
# 内网环境 venv 可能也没有 pip，用 ensurepip
"$VENV/bin/python" -m ensurepip --upgrade 2>/dev/null || true

echo "离线安装 Python 依赖（不联网）..."
"$VENV/bin/pip" install --no-index --find-links="$WHEELS" -r "$REQ"

mkdir -p "$ROOT/data" "$ROOT/run"

if [[ ! -f "$ROOT/config.env" ]]; then
  cp "$ROOT/config.env.example" "$ROOT/config.env"
  echo "已生成 config.env，可按需修改端口等配置"
fi

echo ""
echo "安装完成。下一步:"
echo "  bash scripts/start.sh"
echo "  浏览器打开 http://<本机IP>:8010"
