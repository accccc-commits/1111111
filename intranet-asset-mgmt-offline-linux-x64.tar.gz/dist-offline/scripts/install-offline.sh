#!/usr/bin/env bash
# 目标 Linux 内网环境：仅用本目录自带的 wheel 包安装，不访问外网
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
WHEELS="$ROOT/vendor/wheels"
REQ="$ROOT/backend/requirements.txt"
VENV="$ROOT/.venv"

if ! command -v "$PYTHON" &>/dev/null; then
  echo "错误: 未找到 python3，请先安装 Python 3.10+（系统 ISO 或离线 rpm 包）"
  exit 1
fi

PY_VER="$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
PY_TAG="$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}{sys.version_info.minor}")')"
echo "使用 Python $PY_VER: $($PYTHON -c 'import sys; print(sys.executable)')"

if "$PYTHON" -c 'import sys; exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
  :
else
  echo "错误: 需要 Python 3.10 及以上，当前为 $PY_VER"
  exit 1
fi

# wheel 多为 cp313 等标签；版本不一致时 pip 可能装不全（表现为 no module named uvicorn）
WHEEL_TAG_COUNT=$(ls "$WHEELS"/cp${PY_TAG}-*.whl 2>/dev/null | wc -l | tr -d ' ')
if [[ "$WHEEL_TAG_COUNT" == "0" ]]; then
  echo "警告: vendor/wheels 中未找到 cp${PY_TAG} 架构 wheel（当前仅有其它 Python 版本）"
  echo "  请在打包机用与客户机相同的 Python 重新打包，例如:"
  echo "  PY_TAG=${PY_TAG} bash scripts/prepare-offline-package.sh"
  echo "  继续安装可能失败或缺少依赖..."
fi

if [[ ! -d "$WHEELS" ]] || [[ -z "$(ls -A "$WHEELS" 2>/dev/null || true)" ]]; then
  echo "错误: 未找到 vendor/wheels 离线依赖包"
  echo "请在可联网的 Linux 上执行 scripts/prepare-offline-package.sh 生成完整安装包"
  exit 1
fi

if [[ ! -f "$REQ" ]]; then
  echo "错误: 缺少 $REQ"
  exit 1
fi

echo "创建虚拟环境 $VENV ..."
"$PYTHON" -m venv "$VENV"
# 内网环境 venv 可能也没有 pip，用 ensurepip
"$VENV/bin/python" -m ensurepip --upgrade 2>/dev/null || true

ARCH="$(uname -m 2>/dev/null || echo unknown)"
if [[ "$ARCH" != "x86_64" && "$ARCH" != "amd64" ]]; then
  echo "错误: 离线包仅支持 Linux x86_64，当前架构: $ARCH"
  exit 1
fi

echo "离线安装 Python 依赖（不联网）..."
if ! "$VENV/bin/pip" install --no-index --find-links="$WHEELS" -r "$REQ"; then
  echo ""
  echo "错误: 离线 pip 安装失败。常见原因:"
  echo "  1) 客户机 Python 版本与打包时不一致（请对齐 PY_TAG 后重新打离线包）"
  echo "  2) 系统 glibc 过旧（CentOS 7），请升级 OS 或换 Python 3.11 离线包"
  echo "  3) 安装包不完整，或打包机不是 Linux x86_64"
  echo "  4) 未安装 python3-venv / ensurepip 不可用"
  echo ""
  echo "请执行: bash scripts/check-linux-env.sh"
  echo "并把 pip 报错中 'is not a supported wheel' 的行发给技术支持"
  exit 1
fi

echo "校验关键依赖..."
for mod in uvicorn fastapi sqlalchemy pydantic; do
  if ! "$VENV/bin/python" -c "import ${mod}" 2>/dev/null; then
    echo "错误: 未安装模块 ${mod}，请检查上方 pip 报错或 Python 版本是否匹配"
    exit 1
  fi
done
"$VENV/bin/python" -c "import uvicorn; print('  uvicorn', uvicorn.__version__, 'OK')"

mkdir -p "$ROOT/data" "$ROOT/run"

if [[ ! -f "$ROOT/config.env" ]]; then
  cp "$ROOT/config.env.example" "$ROOT/config.env"
  echo "已生成 config.env，可按需修改端口等配置"
fi

echo ""
echo "安装完成。下一步:"
echo "  bash scripts/start.sh"
echo "  浏览器打开 http://<本机IP>:8010"
