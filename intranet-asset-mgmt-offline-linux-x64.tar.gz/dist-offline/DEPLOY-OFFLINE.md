# 内网 Linux 离线部署说明

客户环境：**不出网**。目标机只需 **Python 3.10+** 和 **bash**，不需要 Node、不需要 pip 访问互联网。

**硬件/系统要求（重要）**

| 项目 | 要求 |
|------|------|
| CPU | **x86_64（amd64）** 64 位，不支持 32 位 i686、不支持 ARM |
| 操作系统 | 建议 **CentOS 8+ / Ubuntu 20.04+ / 麒麟 V10** 等（glibc ≥ 2.17） |
| Python | 与离线包一致，如 **3.13.x**；客户 `python3 --version` 须与打包 `PY_TAG` 一致 |
| 打包机 | **必须在 Linux x86_64** 执行 `prepare-offline-package.sh`（Mac 上打容易出现客户机 wheel 不兼容） |

## 架构说明

| 环境 | 作用 |
|------|------|
| 打包机（可联网 Linux x64） | 下载 wheel、构建前端、打 tar 包 |
| 内网服务器 | 解压 → `install-offline.sh` → `start.sh` |

运行后 **单进程**：`8010` 端口同时提供 API + 网页（`frontend_dist`）。

存活探测使用系统 `ping`，需安装 `iputils`（一般已有）。

---

## 一、在打包机生成离线包（有网 Linux）

要求：与内网服务器相近的 Linux（建议 **CentOS 7+ / Ubuntu 20.04+ / 麒麟 x86_64**），Python 3.10+，Node 18+（仅打包时用）。

```bash
cd intranet-asset-mgmt
chmod +x scripts/*.sh
bash scripts/prepare-offline-package.sh
```

生成文件：`intranet-asset-mgmt-offline-linux-x64.tar.gz`（约几十 MB，含 wheel + 前端静态文件）。

用 U 盘 / 摆渡机拷贝到内网。

> 若打包机是 macOS，请在 **Linux 虚拟机或 Docker** 里执行上述脚本，否则 wheel 架构不匹配。

### Docker 打包示例（Mac 开发机）

```bash
docker run --rm -v "$(pwd):/app" -w /app node:18-bookworm bash -c "
  apt-get update && apt-get install -y python3 python3-pip python3-venv rsync &&
  bash scripts/prepare-offline-package.sh
"
```

---

## 二、内网服务器安装（无网）

```bash
tar -xzf intranet-asset-mgmt-offline-linux-x64.tar.gz
cd intranet-asset-mgmt-offline-linux-x64

# 仅需系统自带 python3
bash scripts/install-offline.sh

# 可选：编辑端口
cp config.env.example config.env
# vi config.env

bash scripts/start.sh
```

浏览器访问：`http://<服务器IP>:8010`

停止服务：

```bash
bash scripts/stop.sh
```

日志：`run/app.log`  
数据库：`data/intranet_assets.db`

---

## 三、系统依赖（内网 ISO 预装）

| 组件 | 说明 |
|------|------|
| python3 ≥ 3.10 | 必须 |
| python3-venv 或 ensurepip | 创建虚拟环境 |
| ping | 存活探测（`iputils` 包） |

无需：Node、npm、外网 pip 源。

---

## 四、防火墙

```bash
# firewalld 示例
firewall-cmd --permanent --add-port=8010/tcp
firewall-cmd --reload
```

---

## 五、常见问题

**Q: install 提示找不到 vendor/wheels？**  
A: 必须使用 `prepare-offline-package.sh` 打好的完整包，不要只拷源码目录。

**Q: 打开页面空白？**  
A: 确认存在 `frontend_dist/index.html`；查看 `run/app.log`。

**Q: Python 版本不一致？**  
A: 打包时设置与客户机一致，例如：`PY_TAG=310 bash scripts/prepare-offline-package.sh`

**Q: 想换端口？**  
A: 编辑 `config.env` 中 `INTRANET_PORT=8080` 后重新 `start.sh`。

**Q: 启动报错 `No module named uvicorn`？**  
A: 说明依赖未装进虚拟环境，按顺序排查：

```bash
cd dist-offline   # 解压后的目录名以实际为准
python3 --version # 记下主版本，如 3.10 / 3.11 / 3.13

rm -rf .venv
bash scripts/install-offline.sh

.venv/bin/python -c "import uvicorn; print(uvicorn.__version__)"
bash scripts/start.sh
```

若 `install-offline.sh` 提示 **未找到 cpXXX wheel** 或 pip 失败：客户机 Python 与打包时不一致。在打包机用**相同版本**重新打离线包，例如客户是 3.10：

```bash
PY_TAG=310 bash scripts/prepare-offline-package.sh
```

不要直接用系统 `python3 -m uvicorn` 启动，必须用 `scripts/start.sh`（走 `.venv`）。

**Q: pip 提示 wheel 不兼容 / version incompatible？**  
A: 多为 **架构或 glibc** 问题，先执行:

```bash
bash scripts/check-linux-env.sh
```

- 架构不是 `x86_64` → 换 64 位服务器，或单独打对应架构包  
- `cp313` wheel 找不到 → Python 小版本与打包不一致，用 `PY_TAG=313` 在 **Linux x86_64** 重打离线包  
- **CentOS 7** 等老系统 → 建议换 **Python 3.11 + `PY_TAG=311`** 重打包，或升级 OS  
- 打包机在 **Mac** 上打的包 → 必须在 **Linux x86_64 Docker/虚拟机** 里重新执行 `prepare-offline-package.sh`

---

## 六、目录结构（离线包内）

```
intranet-asset-mgmt-offline-linux-x64/
├── backend/           # 后端代码
├── frontend_dist/     # 已构建前端（无需 Node）
├── vendor/wheels/     # Python 离线安装包
├── scripts/
│   ├── install-offline.sh
│   ├── start.sh
│   └── stop.sh
├── templates/         # CSV 导入模板
├── config.env.example
└── data/              # 安装后生成，存数据库
```
